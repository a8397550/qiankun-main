(function(global) {
  var config = {};
  config.container = ""
  config.basename = undefined;
  config.type = undefined;
  config.version = "1.0.0";
  config.hash = "1234567890"

  global['__pad_show_build_config__'] = config;
})(window);

